//
//  Meme.swift
//  OnesmallprojectOfMemeME
//
//  Created by Amjad khalid  on 16/11/2018.
//  Copyright © 2018 Amjad khaled. All rights reserved.
//

import UIKit

struct Meme {
    
    var topTextField = ""
    var botoomTextField = ""
    var orignalImage: UIImage?
    var memedImage: UIImage?
    
    
}
